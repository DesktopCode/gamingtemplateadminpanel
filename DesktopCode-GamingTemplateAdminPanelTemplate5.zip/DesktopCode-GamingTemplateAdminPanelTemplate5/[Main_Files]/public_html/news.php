<?php
session_start();
include('includes/config.php');
$username = $_SESSION['username'];
$sql = "SELECT * FROM `usermanagement` WHERE username='$username'";
$res = mysqli_query($connection, $sql);
$r = mysqli_fetch_assoc($res);
$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);

if (empty($_SESSION['token'])) {
 $_SESSION['token'] = bin2hex(random_bytes(32));
}
if(isset($_POST['submit']))
{
  //Verifying CSRF Token
if (!empty($_POST['csrftoken'])) {
if (hash_equals($_SESSION['token'], $_POST['csrftoken'])) {
$name=$r['username'];
$email=$r['email'];
$comment=$_POST['comment'];
$postid=intval($_GET['nid']);
$st1='1';
$query=mysqli_query($con,"insert into tblcomments(postId,name,email,comment,status) values('$postid','$name','$email','$comment','$st1')");
if($query):
$dellmsg="Comment Successfully Posted";
  unset($_SESSION['token']);
else :
 echo "<script>alert('Something went wrong. Please try again.');</script>";  

endif;

}
}
}

if($_GET['action']=='del' && $_GET['rid'])
{
	$id=intval($_GET['rid']);
	$query=mysqli_query($con,"delete from tblcomments where id='$id'");
	$delmsg="Comment Successfully Deleted";
}

?>
<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<title><?php echo $row1['SiteTitle'];?></title>
                  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
                  <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
                  <meta name="description" content="<?php echo $row1['Description'];?>">
	<link rel="shortcut icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">
	<link rel="icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">

	<!-- CSS Plugins -->
	<link rel="stylesheet" href="plugins/slick/slick.css">
	<link rel="stylesheet" href="plugins/font-awesome/brands.css">
                  <link rel="stylesheet" href="css/font-awesome.min.css">
                  <link rel="stylesheet" href="css/9.css">
                  <link rel="stylesheet" href="plugins/font-awesome/fontawesome.min.css">
                  <link rel="stylesheet" href="plugins/font-awesome/solid.css">
 <link rel="stylesheet" href="css/w3.css">

                  <!-- Bootstrap -->
                  
                  <link href="css/boot/bootstrap.min.css" rel="stylesheet">

	<!-- # Main Style Sheet -->
	<link rel="stylesheet" href="css/style.css">

                 <!-- Font -->
                 <link rel="preconnect" href="https://fonts.googleapis.com">
                 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php echo $rowfont['FontURL'];?>
   <style>
   html *
   {
    font-family:<?php echo $rowfont['FontName'];?>;
   }
   </style>
</head>
<body>

<!-- navigation -->
<header class="navigation bg-tertiary">
	<nav class="navbar navbar-expand-xl navbar-light text-center py-3">
		<div class="container">
			
		
			
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mx-auto mb-2 mb-lg-0">
				
<?php $query=mysqli_query($con,"select * from tblheaders WHERE Is_Active = '1' order by LeftRight asc");
while($row=mysqli_fetch_array($query))
{
?>
<li class="nav-item"><a class="nav-link" href="<?php echo $row['Description'];?>"><font style="font-size:20px;"><?php echo $row['HeaderName'];?></font></a></li>
<?php
}
?>
				</ul>
		
			</div>
		</div>
	</nav>
</header>
<!-- /navigation -->




<div>
<div class="page-header bg-tertiary2">
</div>
</div>


<section>
	<div class="container">
		<div class="row">
			<div class="col-lg-9">
				<div class="me-lg-4">
					<div class="row gy-2">
						<div class="col-md-12">
						<div>
						<img class="img-responsive" src="admin/postimages/<?php echo $row1['SiteLogo'];?>" style="border-radius:10px; margin-top:5px; border:2px solid #0d6efd;">
						</div>
						</div>	
						<div>	
						<div class="pt-4">
					
															

<?php
$pid=intval($_GET['nid']);
$query=mysqli_query($con,"select tblposts.PostTitle as posttitle,tblposts.PostImage,tblcategory.CategoryName as category,tblcategory.id as cid,tblsubcategory.Subcategory as subcategory,tblposts.PostDetails as postdetails,tblposts.PostingDate as postingdate,tblposts.PostUrl as url from tblposts left join tblcategory on tblcategory.id=tblposts.CategoryId left join  tblsubcategory on  tblsubcategory.SubCategoryId=tblposts.SubCategoryId where tblposts.id='$pid'");
while ($row=mysqli_fetch_array($query)) {
?>
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 2px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
          <div>
            <div class="card-body"><center>
              <font style="font-size:28px; color: #0d6efd;"><?php echo htmlentities($row['posttitle']);?></font>
              <p><font color="#0d6efd"><b>Category : </b></font> <font color="white"><?php echo htmlentities($row['category']);?></font> |
                <font color="#0d6efd"><b>Posted on </b></font><font color="white"><?php echo htmlentities($row['postingdate']);?></font></p></center>
                <hr />

 <img class="img-fluid rounded" src="admin/postimages/<?php echo htmlentities($row['PostImage']);?>" alt="<?php echo htmlentities($row['posttitle']);?>">
  
             <center><p class="card-text" style="font-size:18px; color:white;"><?php
$pt=$row['postdetails'];
              echo  (substr($pt,0));?></p></center>
             </div>
            </div>
</div>

<?php if($delmsg){ ?>
<div class="alert alert-danger" role="alert">
<strong> <?php echo htmlentities($delmsg);?></strong></div>
<?} ?>
<?php if($dellmsg){ ?>
<div class="alert alert-success" role="alert">
<strong> <?php echo htmlentities($dellmsg);?></strong></div>
<?php } ?>


<?php } ?>
       

<?php
if ($r['active'] && $username == $_SESSION['username']) {
?><br><br>

<div class="col-md-12">

            <h5 class="card-header">Leave a Comment as <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#4CBB17"><?=$r['username'];?></font></B></h5>
            <div class="card-body">
              <form name="Comment" method="post">
                <input type="hidden" name="csrftoken" value="<?php echo htmlentities($_SESSION['token']); ?>" />
                <div class="form-group">
                <textarea class="form-control" name="comment" rows="3" placeholder="Comment" required></textarea>
                </div>
                <center><button type="submit" class="btn btn-primary" name="submit">Submit</button></center>
              </form>
            </div>
          </div>

<?php
}
?>
  <!---Comment Display Section --->

<?php
$querylimit3=mysqli_query($con,"select * from tblpagelimits WHERE id='2'");
$rowlimit3=mysqli_fetch_array($querylimit3);
     if (isset($_GET['pagenom'])) {
            $pageno = $_GET['pagenom'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = $rowlimit3['Limits'];
        $offset = ($pageno-1) * $no_of_records_per_page;
        $total_pages_sql = "SELECT COUNT(*) FROM tblcomments where tblcomments.postId='$pid'";
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);
?>
<?php 
 $sts=1;
 $cnt=1;
 $query=mysqli_query($con,"Select tblcomments.id, tblcomments.name,tblcomments.email,tblcomments.postingDate,tblcomments.comment,tblposts.id as postid,tblposts.PostTitle from  tblcomments join tblposts on tblposts.id=tblcomments.postId where tblcomments.postId='$pid' and tblcomments.status='$sts' order by tblcomments.postingDate desc LIMIT $offset, $no_of_records_per_page");
while ($row=mysqli_fetch_array($query)) {
$querypic=mysqli_query($con,"Select name from tblcomments where postId='$pid' and tblcomments.status='$sts'");
$rowpic=mysqli_fetch_array($querypic);
$rowname = $rowpic['name'];
$rowname1 = $row['name'];
$querypic=mysqli_query($con,"Select profilepic from usermanagement where username='$rowname1'");
$rowpic=mysqli_fetch_array($querypic);
?>
<br>
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 2px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
<div class="media mb-4">
<a href="profile.php?name=<?php echo $row['name'];?>"><img src="images/<?php echo $rowpic['profilepic'];?>" style="border-radius: 25px;" width="100" height="100"></a>
<div class="media-body">
<?php
if ($r['active'] && $r['username'] == $row['name']) {
?>
&nbsp;&nbsp;&nbsp;<font size="5" style="font-weight:bold; text-shadow: 1px 1px 1px black;" color="black"><a href="profile.php?name=<?php echo $row['name'];?>" style="color: green;"><span><?php echo htmlentities($row['name']);?></a></font><br>
<?php
}else{
?>
&nbsp;&nbsp;&nbsp;<font size="5" style="font-weight:bold; text-shadow: 1px 1px 1px black;" color="black"><a href="profile.php?name=<?php echo $row['name'];?>" style="color:#0d6efd;"><?php echo htmlentities($row['name']);?></a></font><br>
<?php
}
?>
&nbsp;&nbsp;&nbsp;<span style="font-size:12px;"><font color="#0d6efd"><?php echo htmlentities($row['postingDate']);?></font><br>
                
&nbsp;&nbsp;&nbsp;&nbsp;<font size="4" color="white"><?php echo htmlentities($row['comment']);?></font>
<?php
if ($r['active'] && $r['username'] == $row['name']) {
?>
<a href="news.php?nid=<?php echo $pid;?>&rid=<?php echo $row['id'];?>&&action=del"><font size="4"><b><i class="fa fa-times" aria-hidden="true" style="color: #e60c0c"></i></b></font></a>
<?php
}
?>
</div>
</div>
</div>
<?php } ?>

<br><br>
<center>
<?php 
$pagenoprev = ($pageno -1);
?>
          <ul class="pagination justify-content-center sm-12">
          <li class="page-item"><a href="?nid=<?php echo $pid;?>&pagenom=1"  class="page-link">First</a></li>
          <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?> page-item">
          <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?nid=$pid&pagenom=".($pageno - 1); } ?>" class="page-link">Prev</a>
          </li>
          <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?> page-item">
          <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?nid=$pid&pagenom=".($pageno + 1); } ?>" class="page-link">Next</a>
          </li>
          <li class="page-item"><a href="?nid=<?php echo $pid;?>&pagenom=<?php echo $total_pages; ?>" class="page-link">Last</a></li>
</ul>
</center>

        
   







                                                                                                            </div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3">
<?php
if ($r['active']) {
?>
				<div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#4CBB17"><?php echo $r['username'];?></font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="profile.php?name=<?php echo $r['username'];?>"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">My Profile</font><small class="ml-auto"></small></a>
						</li>
	                                                                                          <li><a href="logout.php"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">Logout</font><small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } else { ?>
	                                                                    <div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#880808">Offline</font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="login.php">Login<small class="ml-auto"></small></a>
						</li>
						<li><a href="register">Create Account<small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } ?>


								<div class="widget">
			<?php 
$queryres=mysqli_query($con,"select * from tbltabs WHERE PageName='News Top'");
$rowres=mysqli_fetch_array($queryres);
?>
<?php if ($rowres['TabName'] == 'Results') { include 'tab-results.php';
} else if ($rowres['TabName'] == 'News') { include 'tab-news.php'; 
} else if ($rowres['TabName'] == 'Fixtures') { include 'tab-fixtures.php';  
} else if ($rowres['TabName'] == 'Members') { include 'tab-members.php';
}?> 		

				 </div>

	<div class="widget">
			<?php 
$queryres=mysqli_query($con,"select * from tbltabs WHERE PageName='News Bottom'");
$rowres=mysqli_fetch_array($queryres);
?>
<?php if ($rowres['TabName'] == 'Results') { include 'tab-results.php';
} else if ($rowres['TabName'] == 'News') { include 'tab-news.php'; 
} else if ($rowres['TabName'] == 'Fixtures') { include 'tab-fixtures.php';  
} else if ($rowres['TabName'] == 'Members') { include 'tab-members.php';
}?> 		
				 </div>


				 <!-- Social -->
				 <div class="widget">
				 <h4 class="widget-title"><span>Social Links</span></h4>
				 <ul class="list-unstyled list-inline mb-0 social-icons">
<?php
$query=mysqli_query($con,"select * from tblsocial WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>
<font size="4"><li class="list-inline-item me-3"><a class="<?php echo $row['SocialMedia'];?>" href="<?php echo $row['URL'];?>" target="_blank"  style="margin-top:5px;"><i class="fab fa-<?php echo $row['SocialMedia'];?> fa-lg"></i></a></font></li>
<?php
}
?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

<footer class="bg-tertiary">
	<div class="container">
		<div class="row align-items-center mt-5 text-center text-md-start">
			
			<div class="col-lg-12 col-md-6 mt-4 mt-lg-0">
				<ul class="list-unstyled list-inline mb-0 text-lg-center">
					<li class="list-inline-item me-4">
<center><font color="black">Copyright © 2024 All Rights Reserved | DesktopCode | </font><a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a></center>
					</li>

				</ul>
			</div>
		</div>
	</div>
</footer>


<!-- # JS Plugins -->
<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<script src="plugins/slick/slick.min.js"></script>
<script src="plugins/scrollmenu/scrollmenu.min.js"></script>

<!-- Main Script -->
<script src="js/script.js"></script>

</body>
</html>