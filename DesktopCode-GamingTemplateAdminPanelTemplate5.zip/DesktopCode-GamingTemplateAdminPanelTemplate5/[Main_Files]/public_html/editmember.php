<?php
session_start();
include('includes/config.php');
$username = $_SESSION['username'];
$sql = "SELECT * FROM `usermanagement` WHERE username='$username'";
$res = mysqli_query($connection, $sql);
$r = mysqli_fetch_assoc($res);
$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);
$member=strval($_GET['name']);

if(isset($_POST['update']))
{
$realname=$_POST['realname'];
$alias=$_POST['alias'];
$game=$_POST['game'];
$favmap=$_POST['favmap'];
$favweapon=$_POST['favweapon'];
$sensitivity=$_POST['sensitivity'];
$resolution=$_POST['resolution'];
$mouse=$_POST['mouse'];
$keyboard=$_POST['keyboard'];
$headset=$_POST['headset'];
$about=$_POST['about'];
$arr = explode(" ",$realname);
$url=implode("-",$arr);
$status=1;
$memberid=intval($_GET['pid']);
$member=strval($_GET['name']);
$query=mysqli_query($con,"update tblteam set Name='$realname',Alias='$alias',Game='$game',FavMap='$favmap',FavWeapon='$favweapon',Sensitivity='$sensitivity',Resolution='$resolution',Mouse='$mouse',Keyboard='$keyboard',Headset='$headset',About='$about' where Alias='$member'");
if($query)
{
$msg="Clan Member '$alias' Has Been Updated!";
}
else{
$error="Something Went Wrong! Please Try Again!";
} 

}
?>
<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<title><?php echo $row1['SiteTitle'];?></title>
                  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
                  <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
                  <meta name="description" content="<?php echo $row1['Description'];?>">
	<link rel="shortcut icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">
	<link rel="icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">

	<!-- CSS Plugins -->
	<link rel="stylesheet" href="plugins/slick/slick.css">
	<link rel="stylesheet" href="plugins/font-awesome/brands.css">
                  <link rel="stylesheet" href="css/font-awesome.min.css">
                  <link rel="stylesheet" href="css/matches.css">
                  <link rel="stylesheet" href="css/9.css">
                  <link rel="stylesheet" href="plugins/font-awesome/fontawesome.min.css">
                  <link rel="stylesheet" href="plugins/font-awesome/solid.css">
 <link rel="stylesheet" href="css/w3.css">

                  <!-- Bootstrap -->
                  <link href="css/boot/bootstrap.min.css" rel="stylesheet">

	<!-- # Main Style Sheet -->
	<link rel="stylesheet" href="css/style.css">

                 <!-- Font -->
                 <link rel="preconnect" href="https://fonts.googleapis.com">
                 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php echo $rowfont['FontURL'];?>
   <style>
   html *
   {
    font-family:<?php echo $rowfont['FontName'];?>;
   }
   </style>
</head>
<body>

<!-- navigation -->
<header class="navigation bg-tertiary">
	<nav class="navbar navbar-expand-xl navbar-light text-center py-3">
		<div class="container">
			
		
			
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mx-auto mb-2 mb-lg-0">
				
<?php $query=mysqli_query($con,"select * from tblheaders WHERE Is_Active = '1' order by LeftRight asc");
while($row=mysqli_fetch_array($query))
{
?>
<li class="nav-item"><a class="nav-link" href="<?php echo $row['Description'];?>"><font style="font-size:20px;"><?php echo $row['HeaderName'];?></font></a></li>
<?php
}
?>
				</ul>
		
			</div>
		</div>
	</nav>
</header>
<!-- /navigation -->




<div>
<div class="page-header bg-tertiary2">
</div>
</div>


<section>
	<div class="container">
		<div class="row">
			<div class="col-lg-9">
				<div class="me-lg-4">
					<div class="row gy-2">
						<div class="col-md-12">
						<div>
						<img class="img-responsive" src="admin/postimages/<?php echo $row1['SiteLogo'];?>" style="border-radius:10px; margin-top:5px; border:2px solid #0d6efd;">
						</div>
						</div>	
						<div>	
						<div class="pt-4">



<?php
$member=strval($_GET['name']);
?>

<?php
if ($r['active'] && $r['username'] == $member) {
?>

<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">

		<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Private Messages</font> &nbsp; <a href="profilepm.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>


</div>
<br><br>
<?php } ?>
<?php
if ($r['active'] && $r['username'] == $member) {
?>
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">

		<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Friends List</font> &nbsp; <a href="profilefriends.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>


</div>
<br><br>
<?php } ?>
<?php
if ($r['active'] && $r['username'] == $member) {
?>

<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">

		<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Profile Picture</font> &nbsp; <a href="profilepicture.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>


</div>
<br><br>
<?php } ?>				
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">

		<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Forum Comments</font> &nbsp; <a href="profileforum.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>


</div>
<br><br>
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">

		<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Post News Comments</font> &nbsp; <a href="profilepostcomments.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>


</div>
<br><br>

<?php
if ($r['active'] && $r['username'] == $member) {
?>						


<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
		
<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Support Queries</font> &nbsp; <a href="profilequeries.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>
</div>
<br><br>
<?php } ?>

<?php
if ($r['active'] && $r['username'] == $member) {
?>

<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
	
<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Profile Settings</font> &nbsp; <a href="profilesettings.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>
<?php } ?>
</div>
<br><br>

<?php
$member=strval($_GET['name']);
$querymem=mysqli_query($con,"select Alias from tblteam where Alias='$member'");
$rowmem=mysqli_fetch_array($querymem);
?>
<?php
if ($r['active'] && $r['username'] == $rowmem['Alias']) {
?>

<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
	
<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Clan Member Settings</font> &nbsp; <a href="editmember.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>
<?php } ?>
</div>
<br><br>
<div class="col-lg-12">
<?php if($msg){ ?>
<div class="alert alert-success alert-dismissible" role="alert">
<center><strong><font size="4"><?php echo htmlentities($msg);?></font></strong></center>
</div>
<?php } ?>
</div>
<div class="col-lg-12">
<?php if($error){ ?>
<div class="alert border-danger alert-dismissible" role="alert">
<strong><?php echo htmlentities($error);?></strong> 
</div>
<?php } ?>
</div>
<br>
<aside id="sidebar9">
<?php
$member=strval($_GET['name']);
$query=mysqli_query($con,"select tblteam.Name,tblteam.Alias,tblteam.Game,tblteam.FavMap,tblteam.FavWeapon,tblteam.Sensitivity,tblteam.Resolution,tblteam.Mouse,tblteam.Keyboard,tblteam.Headset,tblteam.About,tblteam.Avatar from tblteam where Alias='$member'");
while($row=mysqli_fetch_array($query))
{
?>

                            <div class="col-md-12">
                                <div class="p-6">
                                    <div class="">
<form name="addpost" method="post">
<div class="form-group m-b-20">
<label for="exampleInputEmail1">Real Name</label>
<input type="text" id="realname" value="<?php echo htmlentities($row['Name']);?>" name="realname" placeholder="Enter Name" style="width:100%;" required>
</div>

<div class="form-group m-b-20">
<label for="exampleInputEmail1">Alias</label>
<input type="text" id="alias" value="<?php echo htmlentities($row['Alias']);?>" name="alias" placeholder="Enter Alias" style="width:100%;" required>
</div>

<div class="form-group m-b-20">
<label for="exampleInputEmail1">Team</label>
<select name="game" id="game" onChange="getSubCat(this.value);" required>
<option value="<?php echo htmlentities($row['Game']);?>" class="selectteam" style="width:100%;"><?php echo htmlentities($row['Game']);?></option>
<?php
// Feching active categories
$ret=mysqli_query($con,"select GameName from tblgames where Is_Active=1");
while($result=mysqli_fetch_array($ret))
{    
?>
<option value="<?php echo htmlentities($result['GameName']);?>" class="selectteam"  style="width:100%;"><?php echo htmlentities($result['GameName']);?></option>
<?php } ?>
</select> 
</div>

<div class="form-group m-b-10">
<label for="exampleInputEmail1">Favourite Map</label>
<input type="text" id="favmap" value="<?php echo htmlentities($row['FavMap']);?>" name="favmap" placeholder="Enter Favourite Map"  style="width:100%;" required>
</div>

<div class="form-group m-b-20">
<label for="exampleInputEmail1">Favourite Weapon</label>
<input type="text" id="favweapon" value="<?php echo htmlentities($row['FavWeapon']);?>" name="favweapon" placeholder="Enter Favourite Weapon" style="width:100%;" required>
</div>

<div class="form-group m-b-20">
<label for="exampleInputEmail1">Sensitivity</label>
<input type="text" id="sensitivity" value="<?php echo htmlentities($row['Sensitivity']);?>" name="sensitivity" placeholder="Enter Sensitivity" style="width:100%;" required>
</div>

<div class="form-group m-b-20">
<label for="exampleInputEmail1">Resolution</label>
<input type="text" id="resolution" value="<?php echo htmlentities($row['Resolution']);?>" name="resolution" placeholder="Enter Resolution" style="width:100%;" required>
</div>

<div class="form-group m-b-20">
<label for="exampleInputEmail1">Mouse</label>
<input type="text" id="mouse" value="<?php echo htmlentities($row['Mouse']);?>" name="mouse" placeholder="Enter Mouse" style="width:100%;" required>
</div>

<div class="form-group m-b-20">
<label for="exampleInputEmail1">Keyboard</label>
<input type="text" id="keyboard" value="<?php echo htmlentities($row['Keyboard']);?>" name="keyboard" placeholder="Enter Keyboard" style="width:100%;" required>
</div>

<div class="form-group m-b-20">
<label for="exampleInputEmail1">Headset</label>
<input type="text" id="headset" value="<?php echo htmlentities($row['Headset']);?>" name="headset" placeholder="Enter Headset" style="width:100%;" required>
</div>

<div class="row">
<div class="col-sm-12">
<div class="card-box">

<h4 class="m-b-30 m-t-0 header-title"><font color="#0d6efd"><b>About</b></font></h4><center>
<textarea class="summernote" name="about" rows="8" cols="60" required><?php echo htmlentities($row['About']);?></textarea>
</div>
</div>
</div><br>
<center><button type="submit" name="update" class="btn btn-primary" style="border-radius:10px;">Update</button><br><br>
<div class="row">
<div class="col-sm-12">
<div class="card-box">
<br><br>
<img class="img-responsive" style="border-radius:10px;" src="admin/postimages/<?php echo htmlentities($row['Avatar']);?>" width="300"/>
<br /><br>
<a href="change-memberavatar.php?name=<?php echo htmlentities($member);?>" class="btn btn-primary">Change Avatar</a><br><br>
<br><br>
<a href="member.php?name=<?php echo $member;?>" class="btn btn-primary" style="border-radius:5px;"><font size="4">View Member Profile</font></a>
<br><br>
</div>
</div>
</div>
</aside>
<?php } ?>

                                                                                                            </div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3">
<?php
if ($r['active']) {
?>
				<div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#4CBB17"><?php echo $r['username'];?></font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="profile.php?name=<?php echo $r['username'];?>"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">My Profile</font><small class="ml-auto"></small></a>
						</li>
	                                                                                          <li><a href="logout.php"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">Logout</font><small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } else { ?>
	                                                                    <div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#880808">Offline</font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="login.php">Login<small class="ml-auto"></small></a>
						</li>
						<li><a href="register">Create Account<small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } ?>


				<div class="widget">
					<h5 class="widget-title"><span>News Headlines</span></h5>
					<!-- post-item -->
					<ul class="list-unstyled widget-list">
				
     <?php 
     if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = 5;
        $offset = ($pageno-1) * $no_of_records_per_page;


        $total_pages_sql = "SELECT COUNT(*) FROM tblposts";
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);


$query=mysqli_query($con,"select tblposts.id as pid,tblposts.PostTitle as posttitle,tblposts.PostImage,tblcategory.CategoryName as category,tblcategory.id as cid,tblsubcategory.Subcategory as subcategory,tblposts.PostDetails as postdetails,tblposts.PostingDate as postingdate,tblposts.PostUrl as url from tblposts left join tblcategory on tblcategory.id=tblposts.CategoryId left join  tblsubcategory on  tblsubcategory.SubCategoryId=tblposts.SubCategoryId order by tblposts.id desc  LIMIT $offset, $no_of_records_per_page");
while ($row=mysqli_fetch_array($query)) {
?>
<?php
$pid = $row['pid'];
$total_comments = "SELECT COUNT(*) FROM tblcomments WHERE postId=$pid";
$comresult2 = mysqli_query($con,$total_comments);
$comresult = mysqli_fetch_array($comresult2)[0];
?>
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
                            <div class="news-item"><center>
                                <div class="ni-pic">
                                   <a href="news.php?nid=<?php echo htmlentities($row['pid'])?>"><img src="admin/postimages/<?php echo htmlentities($row['PostImage']);?>" width="150" height="100"></a>
                                </div>
                                <div class="ni-text">
                                   <a href="news.php?nid=<?php echo htmlentities($row['pid'])?>"> <font color="white" size="4"><?php echo htmlentities($row['posttitle']);?></b></a></font><br>
                            
                                        <font color="white"><i class="fa fa-calendar"></i></font> <font color="#0d6efd"><?php echo htmlentities($row['postingdate']);?></font>&nbsp;
                                        <font color="white"><i class="fa fa-edit"></i></font> <font color="#0d6efd">Comments: <?php echo $comresult;?></font>
                                    <br>
                                </div>
                            </div>
</div>
<br>
<?php
}
?>			
					</ul>
				 </div>



				 <!-- Social -->
				 <div class="widget">
				 <h4 class="widget-title"><span>Social Links</span></h4>
				 <ul class="list-unstyled list-inline mb-0 social-icons">
<?php
$query=mysqli_query($con,"select * from tblsocial WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>
<font size="4"><li class="list-inline-item me-3"><a class="<?php echo $row['SocialMedia'];?>" href="<?php echo $row['URL'];?>" target="_blank"  style="margin-top:5px;"><i class="fab fa-<?php echo $row['SocialMedia'];?> fa-lg"></i></a></font></li>
<?php
}
?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

<footer class="bg-tertiary">
	<div class="container">
		<div class="row align-items-center mt-5 text-center text-md-start">
			
			<div class="col-lg-12 col-md-6 mt-4 mt-lg-0">
				<ul class="list-unstyled list-inline mb-0 text-lg-center">
					<li class="list-inline-item me-4">
<center><font color="black">Copyright © 2024 All Rights Reserved | DesktopCode | </font><a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a></center>
					</li>

				</ul>
			</div>
		</div>
	</div>
</footer>


<!-- # JS Plugins -->
<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<script src="plugins/slick/slick.min.js"></script>
<script src="plugins/scrollmenu/scrollmenu.min.js"></script>

<!-- Main Script -->
<script src="js/script.js"></script>

</body>
</html>