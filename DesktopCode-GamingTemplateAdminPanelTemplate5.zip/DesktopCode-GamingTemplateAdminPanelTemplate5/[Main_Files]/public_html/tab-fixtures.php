                                                                        <h5 class="widget-title"><span>Latest Fixtures</span></h5>
				<ul class="list-unstyled widget-list">
				
<?php 
$query=mysqli_query($con,"select * from tblmatchup WHERE Is_Active=1 order by id desc LIMIT 5");
while($rowg=mysqli_fetch_array($query))
{
if ($rowg['Result'] == 'LOSS'){
$fontcolor = '7';
} else If ($rowg['Result'] == 'WIN')
{
$fontcolor = '6';
} else {
$fontcolor = '8';
}
?>
<?php
if ($rowg['Result'] == 'LOSS'){
$fontcolor2 = '#D22B20';
} else If ($rowg['Result'] == 'WIN')
{
$fontcolor2 = 'green';
} else {
$fontcolor2 = '#4169E1';
}
?>
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 2px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
                              <center>
                              <img src="admin/postimages/<?php echo $row1['ClanLogo'];?>" width="30" height="30">
                              <font color="white"><b><?php echo $row1['ClanName'];?></b></font>
                              <font color="white">&nbsp;&nbsp; <b>vs</b> &nbsp;&nbsp;</font>
                              <font color="white"><b><?php echo $rowg['Enemy'];?></b></font>
                              <img src="admin/postimages/<?php echo $rowg['PostImage'];?>" width="30" height="30"><br>
                              <font color ="white"><b><?php echo $rowg['Time'];?></b></font>
                              </center>
</div>
<br>
<?php
}
?>
						
					</ul>