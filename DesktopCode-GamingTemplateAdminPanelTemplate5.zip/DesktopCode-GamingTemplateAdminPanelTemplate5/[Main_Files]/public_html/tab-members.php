                                                                        <h5 class="widget-title"><span>Team Members</span></h5>
				<ul class="list-unstyled widget-list">
				

<style>
hr {
  border: none;
  height: 1px;
  color: #000;  
  background-color: #000; 
}
</style>
<div>	
<div class="col-lg-12 col-md-12">	
<div class="recent-post-content" style="margin-bottom:20px;">
<div>
<?php
$id=intval($_GET['id']);
$queryx=mysqli_query($con,"select id, glogo, GameName from tblgames WHERE Is_Active='1'");
while($rowx=mysqli_fetch_array($queryx)) {
$game = $rowx['GameName'];
$glogo = $rowx['glogo'];
?>

<center>
<div class="media" style="border-bottom:1px solid black;  margin-top:10px;"> 
<button onclick="myFunction('<?php echo $game;?>')" class="w3-button" style="width:100%; height:40%;">
<font size="4" style="margin-left:10px;"><b><?php echo $game;?> <font color="#f52626">▼</font></b></font></button>
</div>
</center>
<div id="<?php echo $game;?>" class="w3-hide">
<?php
$queryc=mysqli_query($con,"SELECT * FROM tblteam where Game='$game' LIMIT 10");
while($rowc=mysqli_fetch_array($queryc)){
?>
<center>
<a href="member.php?name=<?php echo htmlentities($rowc['Alias'])?>"><img class="img-fluid" src="admin/postimages/<?php echo $rowc['Avatar'];?>" width="100" height="100" style="border-radius:5px;margin-top:2px;">
<font size="4" color="black" style="text-shadow: 1px 1px 2px grey;"><b><br><?php echo $rowc['Alias'];?></b></font></a>
</center>
<?php
} 
?>
</div>
<?php
} 
?>
</div>
</div>
</div>
</div>

<script>
function myFunction(id) {
  var x = document.getElementById(id);
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}
</script>
						
					</ul>