<?php
session_start();
include('includes/config.php');
$username = $_SESSION['username'];
$sql = "SELECT * FROM `usermanagement` WHERE username='$username'";
$res = mysqli_query($connection, $sql);
$r = mysqli_fetch_assoc($res);
$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);
$member=strval($_GET['name']); 

 if(isset($_POST['submit2']))
{
    $name1=$r['username'];
    $email1=$r['email'];
    $message1=$_POST['message'];
$arr = explode(" ",$name1);
$url=implode("-",$arr);
$imgfile=$_FILES["postimage"]["name"];
// get the image extension
$extension = substr($imgfile,strlen($imgfile)-4,strlen($imgfile));
// allowed extensions
$allowed_extensions = array(".jpg","jpeg",".png",".gif");
// Validation for allowed extensions .in_array() function searches an array for a specific value.
if(in_array($extension,$allowed_extensions))
{
echo "<script>alert('Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
}
else
{
//rename the image file
$imgnewfile=md5($imgfile).$extension;
// Code for move image into directory
move_uploaded_file($_FILES["postimage"]["tmp_name"],"postimages/".$imgnewfile);

$status=1;
$query=mysqli_query($con,"insert into tblenquiry(Name,Email,Message)values('$name1','$email1','$message1')");
if($query)
{
$msg="Message Sent Successfully!";
}
else{
$error="Something Went Wrong! Please Try Again.";    
} 
}
}

if($_GET['action']=='del' && $_GET['ID'])
{
	$readID=intval($_GET['ID']);
	$query=mysqli_query($con,"delete from  tblprivatemsg  where ID='$readID'");
	$delmsg="Message Deleted!";
}
?>
<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<title><?php echo $row1['SiteTitle'];?></title>
                  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
                  <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
                  <meta name="description" content="<?php echo $row1['Description'];?>">
	<link rel="shortcut icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">
	<link rel="icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">

	<!-- CSS Plugins -->
	<link rel="stylesheet" href="plugins/slick/slick.css">
	<link rel="stylesheet" href="plugins/font-awesome/brands.css">
                  <link rel="stylesheet" href="css/font-awesome.min.css">
                  <link rel="stylesheet" href="css/matches.css">
                  <link rel="stylesheet" href="plugins/font-awesome/fontawesome.min.css">
                  <link rel="stylesheet" href="plugins/font-awesome/solid.css">
 <link rel="stylesheet" href="css/w3.css">

                  <!-- Bootstrap -->
                  <link href="css/boot/bootstrap.min.css" rel="stylesheet">

	<!-- # Main Style Sheet -->
	<link rel="stylesheet" href="css/style.css">

                 <!-- Font -->
                 <link rel="preconnect" href="https://fonts.googleapis.com">
                 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php echo $rowfont['FontURL'];?>
   <style>
   html *
   {
    font-family:<?php echo $rowfont['FontName'];?>;
   }
   </style>
<style>
.tab-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .tab {
            background-color: #293139;
            padding: 10px 20px;
            cursor: pointer;
            border: 1px solid black;
           box-shadow: 0 18px 25px -15px rgba(0, 0, 0, 1);
        }

        .tab-content {
            display: none;
        }

        .active-tab {
            background-color: green;
        }

        .active-content {
            display: block;
        }
</style>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
color:grey;
}
td {
  border: 1px solid #dddddd;
  background-color: white;
  text-align: left;
  padding: 8px;
color:grey;
}
</style>
</head>
<body>

<!-- navigation -->
<header class="navigation bg-tertiary">
	<nav class="navbar navbar-expand-xl navbar-light text-center py-3">
		<div class="container">
			
		
			
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mx-auto mb-2 mb-lg-0">
				
<?php $query=mysqli_query($con,"select * from tblheaders WHERE Is_Active = '1' order by LeftRight asc");
while($row=mysqli_fetch_array($query))
{
?>
<li class="nav-item"><a class="nav-link" href="<?php echo $row['Description'];?>"><font style="font-size:20px;"><?php echo $row['HeaderName'];?></font></a></li>
<?php
}
?>
				</ul>
		
			</div>
		</div>
	</nav>
</header>
<!-- /navigation -->




<div>
<div class="page-header bg-tertiary2">
</div>
</div>


<section>
	<div class="container">
		<div class="row">
			<div class="col-lg-9">
				<div class="me-lg-4">
					<div class="row gy-2">
						<div class="col-md-12">
						<div>
						<img class="img-responsive" src="admin/postimages/<?php echo $row1['SiteLogo'];?>" style="border-radius:10px; margin-top:5px; border:2px solid #0d6efd;">
						</div>
						</div>	
						<div>	
						<div class="pt-4">



<?php
$member=strval($_GET['name']);
?>

<?php
if ($r['active'] && $r['username'] == $member) {
?>

<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">

		<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Private Messages</font> &nbsp; <a href="profilepm.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>


</div>
<br><br>
<?php } ?>

<?php
if ($r['active'] && $r['username'] == $member) {
?>
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">

		<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Friends List</font> &nbsp; <a href="profilefriends.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>


</div>
<br>
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 2px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">

<?php if($delmsg){ ?>
<div class="alert alert-danger" role="alert">
<strong><?php echo htmlentities($delmsg);?></strong></div>
<?php } ?>

<div class="tab-container">
<div class="tab"><a href="addfriend.php?name=<?php echo $member;?>" class="btn btn-success" style="color:#000;font-size:16px; border:1px solid #000; border-radius:5px;text-decoration:none;">Add Friend</a></div>
     <div class="tab"><a href="profilefriends.php?name=<?php echo $member;?>" class="btn btn-success" style="color:#000;font-size:16px; border:1px solid #000; border-radius:5px;text-decoration:none;">Friends</a></div>
     <div class="tab"><a href="profileblocked.php?name=<?php echo $member;?>" class="btn btn-success" style="color:#000;font-size:16px; border:1px solid #000; border-radius:5px;text-decoration:none;">Blocked</a></div>
</div>
<br>

<table>
  <tr>
    <td><font color="black">From</font></td>
    <td><font color="black">Subject</font></td>
    <td><font color="black">Message</font></td>
    <td><font color="black">Reply</font></td>
    <td><center><font color="black">Delete</font></center></td>
  </tr>
<?php 
     if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = 5;
        $offset = ($pageno-1) * $no_of_records_per_page;


        $total_pages_sql = "SELECT COUNT(*) FROM tblprivatemsg";
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);


$readID=intval($_GET['ID']);
$username1=intval($_GET['name']);
$query=mysqli_query($con,"select * from tblprivatemsg where ID='$readID' order by ID LIMIT $offset, $no_of_records_per_page");
while ($row=mysqli_fetch_array($query)) {
?>
  <tr>
    <th><a href="profile.php?name=<?php echo $row['Name'];?>"><?php echo $row['Name'];?></a></th>
    <th><?php echo $row['Subject'];?></th>
    <th><?php echo $row['Message'];?></th>
    <th><a href="friendreply.php?name=<?php echo $member;?>&friend=<?php echo $row['Name'];?>&ID=<?php echo $row['ID'];?>"><font color="green">Reply</font></a></th>
    <th><center><a href="friendread.php?name=<?php echo $member;?>&ID=<?php echo $row['ID'];?>&&action=del"><i class="fa fa-trash" style="color: red"></i></a></center></th>
  </tr>
<?php } ?>
</table><br>
</div>
<hr>
<?php } ?>



<?php
if ($r['active'] && $r['username'] == $member) {
?>

<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">

		<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Profile Picture</font> &nbsp; <a href="profilepicture.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>


</div>
<br><br>
<?php } ?>				

<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">

		<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Forum Comments</font> &nbsp; <a href="profileforum.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>


</div>
<br><br>

<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">

		<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Post News Comments</font> &nbsp; <a href="profilepostcomments.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>


</div>
<br><br>

<?php
if ($r['active'] && $r['username'] == $member) {
?>						


<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
		
<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Support Queries</font> &nbsp; <a href="profilequeries.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>
</div>
<br><br>
<?php } ?>

<?php
if ($r['active'] && $r['username'] == $member) {
?>

<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
	
<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Profile Settings</font> &nbsp; <a href="profilesettings.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>
<?php } ?>
</div>
<br><br>

<?php
$member=strval($_GET['name']);
$querymem=mysqli_query($con,"select Alias from tblteam where Alias='$member'");
$rowmem=mysqli_fetch_array($querymem);
?>
<?php
if ($r['active'] && $r['username'] == $rowmem['Alias']) {
?>

<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
	
<div><center><a href="profile.php?name=<?php echo $member;?>" class="btn-dcred"><font size="4">-</font></a> &nbsp; <font color="white" size="4">Clan Member Settings</font> &nbsp; <a href="editmember.php?name=<?php echo $member;?>" class="btn-dcgreen" style="border-radius:4px;"><font size="4">+</font></a></center></div>
<?php } ?>
</div>
<br><br>



</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3">
<?php
if ($r['active']) {
?>
				<div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#4CBB17"><?php echo $r['username'];?></font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="profile.php?name=<?php echo $r['username'];?>"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">My Profile</font><small class="ml-auto"></small></a>
						</li>
	                                                                                          <li><a href="logout.php"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">Logout</font><small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } else { ?>
	                                                                    <div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#880808">Offline</font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="login.php">Login<small class="ml-auto"></small></a>
						</li>
						<li><a href="register">Create Account<small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } ?>


				<div class="widget">
					<h5 class="widget-title"><span>News Headlines</span></h5>
					<!-- post-item -->
					<ul class="list-unstyled widget-list">
				
     <?php 
     if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = 5;
        $offset = ($pageno-1) * $no_of_records_per_page;


        $total_pages_sql = "SELECT COUNT(*) FROM tblposts";
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);


$query=mysqli_query($con,"select tblposts.id as pid,tblposts.PostTitle as posttitle,tblposts.PostImage,tblcategory.CategoryName as category,tblcategory.id as cid,tblsubcategory.Subcategory as subcategory,tblposts.PostDetails as postdetails,tblposts.PostingDate as postingdate,tblposts.PostUrl as url from tblposts left join tblcategory on tblcategory.id=tblposts.CategoryId left join  tblsubcategory on  tblsubcategory.SubCategoryId=tblposts.SubCategoryId order by tblposts.id desc  LIMIT $offset, $no_of_records_per_page");
while ($row=mysqli_fetch_array($query)) {
?>
<?php
$pid = $row['pid'];
$total_comments = "SELECT COUNT(*) FROM tblcomments WHERE postId=$pid";
$comresult2 = mysqli_query($con,$total_comments);
$comresult = mysqli_fetch_array($comresult2)[0];
?>
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
                            <div class="news-item"><center>
                                <div class="ni-pic">
                                   <a href="news.php?nid=<?php echo htmlentities($row['pid'])?>"><img src="admin/postimages/<?php echo htmlentities($row['PostImage']);?>" width="150" height="100"></a>
                                </div>
                                <div class="ni-text">
                                   <a href="news.php?nid=<?php echo htmlentities($row['pid'])?>"> <font color="white" size="4"><?php echo htmlentities($row['posttitle']);?></b></a></font><br>
                            
                                        <font color="white"><i class="fa fa-calendar"></i></font> <font color="#0d6efd"><?php echo htmlentities($row['postingdate']);?></font>&nbsp;
                                        <font color="white"><i class="fa fa-edit"></i></font> <font color="#0d6efd">Comments: <?php echo $comresult;?></font>
                                    <br>
                                </div>
                            </div>
</div>
<br>
<?php
}
?>			
					</ul>
				 </div>



				 <!-- Social -->
				 <div class="widget">
				 <h4 class="widget-title"><span>Social Links</span></h4>
				 <ul class="list-unstyled list-inline mb-0 social-icons">
<?php
$query=mysqli_query($con,"select * from tblsocial WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>
<font size="4"><li class="list-inline-item me-3"><a class="<?php echo $row['SocialMedia'];?>" href="<?php echo $row['URL'];?>" target="_blank"  style="margin-top:5px;"><i class="fab fa-<?php echo $row['SocialMedia'];?> fa-lg"></i></a></font></li>
<?php
}
?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

<footer class="bg-tertiary">
	<div class="container">
		<div class="row align-items-center mt-5 text-center text-md-start">
			
			<div class="col-lg-12 col-md-6 mt-4 mt-lg-0">
				<ul class="list-unstyled list-inline mb-0 text-lg-center">
					<li class="list-inline-item me-4">
<center><font color="black">Copyright © 2024 All Rights Reserved | DesktopCode | </font><a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a></center>
					</li>

				</ul>
			</div>
		</div>
	</div>
</footer>


<!-- # JS Plugins -->
<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<script src="plugins/slick/slick.min.js"></script>
<script src="plugins/scrollmenu/scrollmenu.min.js"></script>

<!-- Main Script -->
<script src="js/script.js"></script>

</body>
</html>