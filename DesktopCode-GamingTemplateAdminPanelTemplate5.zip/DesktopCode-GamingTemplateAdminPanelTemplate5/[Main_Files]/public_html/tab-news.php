<h5 class="widget-title"><span>News Headlines</span></h5>
					<!-- post-item -->
					<ul class="list-unstyled widget-list">
				
     <?php 
     if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = 5;
        $offset = ($pageno-1) * $no_of_records_per_page;


        $total_pages_sql = "SELECT COUNT(*) FROM tblposts";
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);


$query=mysqli_query($con,"select tblposts.id as pid,tblposts.PostTitle as posttitle,tblposts.PostImage,tblcategory.CategoryName as category,tblcategory.id as cid,tblsubcategory.Subcategory as subcategory,tblposts.PostDetails as postdetails,tblposts.PostingDate as postingdate,tblposts.PostUrl as url from tblposts left join tblcategory on tblcategory.id=tblposts.CategoryId left join  tblsubcategory on  tblsubcategory.SubCategoryId=tblposts.SubCategoryId order by tblposts.id desc  LIMIT $offset, $no_of_records_per_page");
while ($row=mysqli_fetch_array($query)) {
?>
<?php
$pid = $row['pid'];
$total_comments = "SELECT COUNT(*) FROM tblcomments WHERE postId=$pid";
$comresult2 = mysqli_query($con,$total_comments);
$comresult = mysqli_fetch_array($comresult2)[0];
?>
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
                            <div class="news-item"><center>
                                <div class="ni-pic">
                                   <a href="news.php?nid=<?php echo htmlentities($row['pid'])?>"><img src="admin/postimages/<?php echo htmlentities($row['PostImage']);?>" width="150" height="100"></a>
                                </div>
                                <div class="ni-text">
                                   <a href="news.php?nid=<?php echo htmlentities($row['pid'])?>"> <font color="white" size="4"><?php echo htmlentities($row['posttitle']);?></b></a></font><br>
                            
                                        <font color="white"><i class="fa fa-calendar"></i></font> <font color="#0d6efd"><?php echo htmlentities($row['postingdate']);?></font>&nbsp;
                                        <font color="white"><i class="fa fa-edit"></i></font> <font color="#0d6efd">Comments: <?php echo $comresult;?></font>
                                    <br>
                                </div>
                            </div>
</div>
<br>
<?php
}
?>			
					</ul>