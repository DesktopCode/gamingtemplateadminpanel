<?php
session_start();
include('includes/config.php');
$username = $_SESSION['username'];
    $sql = "SELECT * FROM `usermanagement` WHERE username='$username'";
    $res = mysqli_query($connection, $sql);
    $r = mysqli_fetch_assoc($res);
$query=mysqli_query($con,"select ClanName from tblsettings WHERE id=1");
$rowclan=mysqli_fetch_array($query);
$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);

 if(isset($_POST['submit2']))
{
    $name1=$r['username'];
    $email1=$r['email'];
    $message1=$_POST['message'];
$arr = explode(" ",$name1);
$url=implode("-",$arr);
$imgfile=$_FILES["postimage"]["name"];
// get the image extension
$extension = substr($imgfile,strlen($imgfile)-4,strlen($imgfile));
// allowed extensions
$allowed_extensions = array(".jpg","jpeg",".png",".gif");
// Validation for allowed extensions .in_array() function searches an array for a specific value.
if(in_array($extension,$allowed_extensions))
{
echo "<script>alert('Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
}
else
{
//rename the image file
$imgnewfile=md5($imgfile).$extension;
// Code for move image into directory
move_uploaded_file($_FILES["postimage"]["tmp_name"],"postimages/".$imgnewfile);

$status=1;
$query=mysqli_query($con,"insert into tblenquiry(Name,Email,Message)values('$name1','$email1','$message1')");
if($query)
{
$msg="Message Sent Successfully!";
}
else{
$error="Something went wrong . Please try again.";    
} 

}
}
?>
<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<title><?php echo $row1['SiteTitle'];?></title>
                  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
                  <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
                  <meta name="description" content="<?php echo $row1['Description'];?>">
	<link rel="shortcut icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">
	<link rel="icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">

	<!-- CSS Plugins -->
	<link rel="stylesheet" href="plugins/slick/slick.css">
	<link rel="stylesheet" href="plugins/font-awesome/brands.css">
                  <link rel="stylesheet" href="css/font-awesome.min.css">
                  <link rel="stylesheet" href="css/matches.css">
                  <link rel="stylesheet" href="plugins/font-awesome/fontawesome.min.css">
                  <link rel="stylesheet" href="plugins/font-awesome/solid.css">
 <link rel="stylesheet" href="css/w3.css">

                  <!-- Bootstrap -->
                  <link href="css/boot/bootstrap.min.css" rel="stylesheet">

	<!-- # Main Style Sheet -->
	<link rel="stylesheet" href="css/style.css">

                 <!-- Font -->
                 <link rel="preconnect" href="https://fonts.googleapis.com">
                 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php echo $rowfont['FontURL'];?>
   <style>
   html *
   {
    font-family:<?php echo $rowfont['FontName'];?>;
   }
   </style>
</head>
<body>

<!-- navigation -->
<header class="navigation bg-tertiary">
	<nav class="navbar navbar-expand-xl navbar-light text-center py-3">
		<div class="container">
			
		
			
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mx-auto mb-2 mb-lg-0">
				
<?php $query=mysqli_query($con,"select * from tblheaders WHERE Is_Active = '1' order by LeftRight asc");
while($row=mysqli_fetch_array($query))
{
?>
<li class="nav-item"><a class="nav-link" href="<?php echo $row['Description'];?>"><font style="font-size:20px;"><?php echo $row['HeaderName'];?></font></a></li>
<?php
}
?>
				</ul>
		
			</div>
		</div>
	</nav>
</header>
<!-- /navigation -->




<div>
<div class="page-header bg-tertiary2">
</div>
</div>


<section>
	<div class="container">
		<div class="row">
			<div class="col-lg-9">
				<div class="me-lg-4">
					<div class="row gy-2">
						<div class="col-md-12">
						<div>
						<img class="img-responsive" src="admin/postimages/<?php echo $row1['SiteLogo'];?>" style="border-radius:10px; margin-top:5px; border:2px solid #0d6efd;">
						</div>
						</div>	
						<div>	
						<div class="pt-4">

        <?php $query=mysqli_query($con,"select * from tblcontact WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>

                                <h2><?php echo $row['Contact'];?></h2>
                                </div>
                                <div class="kode-forminfo">
                                <p><font size="3"><?php echo $row['ContactInfo'];?></font></p>
                                <ul class="kode-form-list">
                                <p><i class="fa fa-phone"></i> <strong><font size="3"><?php echo $row['Phone'];?>: </font></strong> <font size="3"><?php echo $row['PhoneNumber'];?></font></p>
                                <p><i class="fa fa-envelope"></i> <strong><font size="3"><?php echo $row['Email'];?>: </font></strong> <font size="3"><?php echo $row['EmailAddress'];?></font></p>

				 <ul class="list-unstyled list-inline mb-0 social-icons">
<i class="fa fa-globe"></i> <strong><font size="3">Social Media: </font></strong> 
<?php
$query=mysqli_query($con,"select * from tblsocial WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>
<font size="4"> <li class="list-inline-item me-3"><a class="<?php echo $row['SocialMedia'];?>" href="<?php echo $row['URL'];?>" target="_blank"  style="margin-top:5px;"><i class="fab fa-<?php echo $row['SocialMedia'];?> fa-lg"></i></a></font></li>
<?php
}
?>
					</ul>

<?php
}
?>

<!---Success Message--->  
<?php if($msg){ ?>
<div class="alert alert-success" role="alert">
<strong><?php echo htmlentities($msg);?></strong>
</div>
<?php } ?>

<!---Error Message--->
<?php if($error){ ?>
<div class="alert alert-danger" role="alert">
<strong><?php echo htmlentities($error);?></strong></div>
<?php } ?>


<?php if ($r['active']) { ?>

                                                                                                       <br>
                                                                                                            <div class="contact-agileinfo">
				                                    <div class="col-md-12 contact-form three"><center>
					                  <form name="addpost" method="post" enctype="multipart/form-data">
						<textarea placeholder="Type Your Message Here" name="message" rows="8" cols="50" required=""></textarea><br>
						<input type="submit" name="submit2" class="btn btn-success" value="Submit">
					                  </form>
				                                    </div></div><div class="hidden-me" id="contact_form_responce">

</div>
<?php } else{ ?><br><br>
<center><font size="3" color="black">Login to contact support, or contact support via the email address.</font></center>
<?php
}
?>
</div>


						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3">
<?php
if ($r['active']) {
?>
				<div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#4CBB17"><?php echo $r['username'];?></font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="profile.php?name=<?php echo $r['username'];?>"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">My Profile</font><small class="ml-auto"></small></a>
						</li>
	                                                                                          <li><a href="logout.php"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">Logout</font><small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } else { ?>
	                                                                    <div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#880808">Offline</font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="login.php">Login<small class="ml-auto"></small></a>
						</li>
						<li><a href="register">Create Account<small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } ?>


								<div class="widget">
			<?php 
$queryres=mysqli_query($con,"select * from tbltabs WHERE PageName='About Top'");
$rowres=mysqli_fetch_array($queryres);
?>
<?php if ($rowres['TabName'] == 'Results') { include 'tab-results.php';
} else if ($rowres['TabName'] == 'News') { include 'tab-news.php'; 
} else if ($rowres['TabName'] == 'Fixtures') { include 'tab-fixtures.php';  
} else if ($rowres['TabName'] == 'Members') { include 'tab-members.php';
}?> 		

				 </div>

	<div class="widget">
			<?php 
$queryres=mysqli_query($con,"select * from tbltabs WHERE PageName='About Bottom'");
$rowres=mysqli_fetch_array($queryres);
?>
<?php if ($rowres['TabName'] == 'Results') { include 'tab-results.php';
} else if ($rowres['TabName'] == 'News') { include 'tab-news.php'; 
} else if ($rowres['TabName'] == 'Fixtures') { include 'tab-fixtures.php';  
} else if ($rowres['TabName'] == 'Members') { include 'tab-members.php';
}?> 		
				 </div>


				 <!-- Social -->
				 <div class="widget">
				 <h4 class="widget-title"><span>Social Links</span></h4>
				 <ul class="list-unstyled list-inline mb-0 social-icons">
<?php
$query=mysqli_query($con,"select * from tblsocial WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>
<font size="4"><li class="list-inline-item me-3"><a class="<?php echo $row['SocialMedia'];?>" href="<?php echo $row['URL'];?>" target="_blank"  style="margin-top:5px;"><i class="fab fa-<?php echo $row['SocialMedia'];?> fa-lg"></i></a></font></li>
<?php
}
?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

<footer class="bg-tertiary">
	<div class="container">
		<div class="row align-items-center mt-5 text-center text-md-start">
			
			<div class="col-lg-12 col-md-6 mt-4 mt-lg-0">
				<ul class="list-unstyled list-inline mb-0 text-lg-center">
					<li class="list-inline-item me-4">
<center><font color="black">Copyright © 2024 All Rights Reserved | DesktopCode | </font><a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a></center>
					</li>

				</ul>
			</div>
		</div>
	</div>
</footer>


<!-- # JS Plugins -->
<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<script src="plugins/slick/slick.min.js"></script>
<script src="plugins/scrollmenu/scrollmenu.min.js"></script>

<!-- Main Script -->
<script src="js/script.js"></script>

</body>
</html>