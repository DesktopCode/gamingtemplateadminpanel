<?php
session_start();
include('includes/config.php');
$username = $_SESSION['username'];
$query=mysqli_query($con,"select ClanName from tblsettings WHERE id=1");
$rowclan=mysqli_fetch_array($query);
$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);

$response = null;
if(isset($_POST) & !empty($_POST)){

	if($response == null){
		$username = mysqli_real_escape_string($connection, $_POST['username']);
		$verification_key = md5($username);
		$email = mysqli_real_escape_string($connection, $_POST['email']);
		$password = md5($_POST['password']);
		$passwordagain = md5($_POST['passwordagain']);
		if($password == $passwordagain){
			$fmsg = "";
			
    $stmt2 = $con->prepare("SELECT email FROM usermanagement WHERE email=?");
    $stmt2->bind_param("s", $email);
    $stmt2->execute();
    $result = $stmt2->get_result();
    $stmt2->close();
    $count2 = $result->num_rows;

    $stmt = $con->prepare("SELECT username FROM usermanagement WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    $count = $result->num_rows;

    if ($count == 0 AND $count2 == 0) {
			
			$sql = "INSERT INTO `usermanagement` (username, email, password, profilepic, verification_key, active) VALUES ('$username', '$email', '$password', 'desktopcode-logo.png', '$verification_key', '1')";
			$result = mysqli_query($connection, $sql);
			if($result){
				$smsg = "User Registered Succesfully!";
			

			}else{
				$fmsg = "Failed To Register User!";
			}
		}else{
			$fmsg = "Email and/or Username Already Exist!";
		}
	}
}
}
?>
<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<title><?php echo $row1['SiteTitle'];?></title>
                  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
                  <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
                  <meta name="description" content="<?php echo $row1['Description'];?>">
	<link rel="shortcut icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">
	<link rel="icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">

	<!-- CSS Plugins -->
	<link rel="stylesheet" href="plugins/slick/slick.css">
	<link rel="stylesheet" href="plugins/font-awesome/brands.css">
                  <link rel="stylesheet" href="css/font-awesome.min.css">
                  <link rel="stylesheet" href="css/matches.css">
                  <link rel="stylesheet" href="plugins/font-awesome/fontawesome.min.css">
                  <link rel="stylesheet" href="plugins/font-awesome/solid.css">
 <link rel="stylesheet" href="css/w3.css">

                  <!-- Bootstrap -->
                  <link href="css/boot/bootstrap.min.css" rel="stylesheet">

	<!-- # Main Style Sheet -->
	<link rel="stylesheet" href="css/style.css">

                 <!-- Font -->
                 <link rel="preconnect" href="https://fonts.googleapis.com">
                 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php echo $rowfont['FontURL'];?>
   <style>
   html *
   {
    font-family:<?php echo $rowfont['FontName'];?>;
   }
   </style>
</head>
<body>

<!-- navigation -->
<header class="navigation bg-tertiary">
	<nav class="navbar navbar-expand-xl navbar-light text-center py-3">
		<div class="container">
			
		
			
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mx-auto mb-2 mb-lg-0">
				
<?php $query=mysqli_query($con,"select * from tblheaders WHERE Is_Active = '1' order by LeftRight asc");
while($row=mysqli_fetch_array($query))
{
?>
<li class="nav-item"><a class="nav-link" href="<?php echo $row['Description'];?>"><font style="font-size:20px;"><?php echo $row['HeaderName'];?></font></a></li>
<?php
}
?>
				</ul>
		
			</div>
		</div>
	</nav>
</header>
<!-- /navigation -->




<div>
<div class="page-header bg-tertiary2">
</div>
</div>


<section>
	<div class="container">
		<div class="row">
			<div class="col-lg-9">
				<div class="me-lg-4">
					<div class="row gy-2">
						<div class="col-md-12">
						<div>
						<img class="img-responsive" src="admin/postimages/<?php echo $row1['SiteLogo'];?>" style="border-radius:10px; margin-top:5px; border:2px solid #0d6efd;">
						</div>
						</div>	
						<div>	
						<div class="pt-4">

<div class="col-lg-12">
<center>
<div class="col-lg-12">
<?php if($smsg){ ?>
<div class="alert alert-success alert-dismissible" role="alert">
<center><strong><?php echo htmlentities($smsg);?></strong></center>
</div>
<?php } ?>
</div>

<div class="col-lg-12">
<?php if($fmsg){ ?>
<div class="alert alert-danger alert-dismissible" role="alert">
<div id="btnwrap"><strong><?php echo htmlentities($fmsg);?></strong></div>
</div>
<?php } ?>
</div>
<center>
<div class="panel-heading" id="panel-heading" style="background-color: #262626; border-radius:10px; border: 1px solid #0d6efd; box-shadow: 0 20px 35px -20px rgba(0,0,0,1);">
      <form class="form-signin" method="POST">
        <div><br>
        <input type="text" name="username" id="username" class="form-control" placeholder="Enter Username" style="width:30%;" required>
       <br>
        <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Enter Email Address" style="width:30%;" required>
        <br>
        <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Enter Password" style="width:30%;" required>
        <br><input type="password" name="passwordagain" id="inputPassword" class="form-control" placeholder="Enter Password Again" style="width:30%;" required>
<br><button  class="btn btn-primary" type="submit">Register</button><br><br>
</center>
</div>
</form>
</div>

						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3">
<?php
if ($r['active']) {
?>
				<div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#4CBB17"><?php echo $r['username'];?></font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="profile.php?name=<?php echo $r['username'];?>"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">My Profile</font><small class="ml-auto"></small></a>
						</li>
	                                                                                          <li><a href="logout.php"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">Logout</font><small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } else { ?>
	                                                                    <div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#880808">Offline</font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="login.php">Login<small class="ml-auto"></small></a>
						</li>
						<li><a href="register">Create Account<small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } ?>


								<div class="widget">
			<?php 
$queryres=mysqli_query($con,"select * from tbltabs WHERE PageName='Register Top'");
$rowres=mysqli_fetch_array($queryres);
?>
<?php if ($rowres['TabName'] == 'Results') { include 'tab-results.php';
} else if ($rowres['TabName'] == 'News') { include 'tab-news.php'; 
} else if ($rowres['TabName'] == 'Fixtures') { include 'tab-fixtures.php';  
} else if ($rowres['TabName'] == 'Members') { include 'tab-members.php';
}?> 		

				 </div>

	<div class="widget">
			<?php 
$queryres=mysqli_query($con,"select * from tbltabs WHERE PageName='Register Bottom'");
$rowres=mysqli_fetch_array($queryres);
?>
<?php if ($rowres['TabName'] == 'Results') { include 'tab-results.php';
} else if ($rowres['TabName'] == 'News') { include 'tab-news.php'; 
} else if ($rowres['TabName'] == 'Fixtures') { include 'tab-fixtures.php';  
} else if ($rowres['TabName'] == 'Members') { include 'tab-members.php';
}?> 		
				 </div>



				 <!-- Social -->
				 <div class="widget">
				 <h4 class="widget-title"><span>Social Links</span></h4>
				 <ul class="list-unstyled list-inline mb-0 social-icons">
<?php
$query=mysqli_query($con,"select * from tblsocial WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>
<font size="4"><li class="list-inline-item me-3"><a class="<?php echo $row['SocialMedia'];?>" href="<?php echo $row['URL'];?>" target="_blank"  style="margin-top:5px;"><i class="fab fa-<?php echo $row['SocialMedia'];?> fa-lg"></i></a></font></li>
<?php
}
?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

<footer class="bg-tertiary">
	<div class="container">
		<div class="row align-items-center mt-5 text-center text-md-start">
			
			<div class="col-lg-12 col-md-6 mt-4 mt-lg-0">
				<ul class="list-unstyled list-inline mb-0 text-lg-center">
					<li class="list-inline-item me-4">
<center><font color="black">Copyright © 2024 All Rights Reserved | DesktopCode | </font><a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a></center>
					</li>

				</ul>
			</div>
		</div>
	</div>
</footer>


<!-- # JS Plugins -->
<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<script src="plugins/slick/slick.min.js"></script>
<script src="plugins/scrollmenu/scrollmenu.min.js"></script>

<!-- Main Script -->
<script src="js/script.js"></script>

</body>
</html>