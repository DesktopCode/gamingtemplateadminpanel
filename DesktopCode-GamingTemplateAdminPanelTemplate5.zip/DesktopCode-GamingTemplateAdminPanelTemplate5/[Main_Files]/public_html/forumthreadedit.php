<?php
session_start();
include('includes/config.php');
$username = $_SESSION['username'];
$sql = "SELECT * FROM `usermanagement` WHERE username='$username'";
$res = mysqli_query($connection, $sql);
$r = mysqli_fetch_assoc($res);
$query=mysqli_query($con,"select ClanName from tblsettings WHERE id=1");
$rowclan=mysqli_fetch_array($query);
$query1=mysqli_query($con,"select * from tblsettings WHERE id = '1'");
$row1=mysqli_fetch_array($query1);
$queryfont=mysqli_query($con,"select * from tblfonts WHERE website='1'");
$rowfont=mysqli_fetch_array($queryfont);
$replyid =intval($_GET['rid']);

if (empty($_SESSION['token'])) {
 $_SESSION['token'] = bin2hex(random_bytes(32));
}
if(isset($_POST['submit']))
{
  //Verifying CSRF Token
if (!empty($_POST['csrftoken'])) {
if (hash_equals($_SESSION['token'], $_POST['csrftoken'])) {
$name=$r['username'];
$comment=$_POST['comment'];
$postid=intval($_GET['pid']);
$rostid=intval($_GET['rid']);
$st1='1';
$query=mysqli_query($con,"update tblforumcomments set comment='$comment' where id='$replyid'");
if($query):
$msg="Your Reply Has Been Edited!";
unset($_SESSION['token']);
header("Location: ./forum-thread.php?pid=$postid&rid=$rostid&&action=edit");
else :
echo "<script>alert('Something went wrong. Please try again.');</script>";  

endif;
}
}
}

if($_GET['action']=='del' && $_GET['rid'])
{
	$id=intval($_GET['rid']);
	$query=mysqli_query($con,"delete from tblforumcomments where id='$id'");
	$delmsg="Reply Successfully Deleted";
}
?>
<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<title><?php echo $row1['SiteTitle'];?></title>
                  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
                  <meta name="keywords" content="<?php echo $row1['MetaTags'];?>">
                  <meta name="description" content="<?php echo $row1['Description'];?>">
	<link rel="shortcut icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">
	<link rel="icon" type="image/png" href="admin/postimages/<?php echo $row1['favicon'];?>">

	<!-- CSS Plugins -->
	<link rel="stylesheet" href="plugins/slick/slick.css">
	<link rel="stylesheet" href="plugins/font-awesome/brands.css">
                  <link rel="stylesheet" href="css/font-awesome.min.css">
                  <link rel="stylesheet" href="css/matches.css">
                  <link rel="stylesheet" href="plugins/font-awesome/fontawesome.min.css">
                  <link rel="stylesheet" href="plugins/font-awesome/solid.css">
                  <link rel="stylesheet" href="css/w3.css">
 
                  <!-- Bootstrap -->
                  <link href="css/boot/bootstrap.min.css" rel="stylesheet">

	<!-- # Main Style Sheet -->
	<link rel="stylesheet" href="css/style.css">

                 <!-- Font -->
                 <link rel="preconnect" href="https://fonts.googleapis.com">
                 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php echo $rowfont['FontURL'];?>
   <style>
   html *
   {
    font-family:<?php echo $rowfont['FontName'];?>;
   }
   </style>
<style>
.tab-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .tab {
            background-color: #262626;
            cursor: pointer;
            border: 1px solid black;
            box-shadow: 0 18px 25px -15px #000;
            border-radius:10px;
        }

        .tab2 {
            background-color: #111;
            border-top-right-radius:10px; 
            border-top-left-radius:10px;
            border-bottom:1px solid #0d6efd;
       }

        .tab-content {
            display: none;
        }

        .active-tab {
            background-color: green;
        }

        .active-content {
            display: block;
        }
</style>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 1px;
color:grey;
}
td {
  border: 1px solid #dddddd;
  background-color: white;
  text-align: left;
  padding: 1px;
color:grey;
}
</style>
</head>
<body>

<!-- navigation -->
<header class="navigation bg-tertiary">
	<nav class="navbar navbar-expand-xl navbar-light text-center py-3">
		<div class="container">
			
		
			
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mx-auto mb-2 mb-lg-0">
				
<?php $query=mysqli_query($con,"select * from tblheaders WHERE Is_Active = '1' order by LeftRight asc");
while($row=mysqli_fetch_array($query))
{
?>
<li class="nav-item"><a class="nav-link" href="<?php echo $row['Description'];?>"><font style="font-size:20px;"><?php echo $row['HeaderName'];?></font></a></li>
<?php
}
?>
				</ul>
		
			</div>
		</div>
	</nav>
</header>
<!-- /navigation -->




<div>
<div class="page-header bg-tertiary2">
</div>
</div>


<section>
	<div class="container">
		<div class="row">
			<div class="col-lg-9">
				<div class="me-lg-4">
					<div class="row gy-2">
						<div class="col-md-12">
						<div>
						<img class="img-responsive" src="admin/postimages/<?php echo $row1['SiteLogo'];?>" style="border-radius:10px; margin-top:5px; border:2px solid #0d6efd;">
						</div>
						</div>	
						<div>	
						<div class="pt-4">


<font size="5"><a href="javascript:history.back()" class="btn btn-danger" style="border:1px solid black;">◄ Back</a></font>
<?php
$threadid =intval($_GET['pid']);
$query=mysqli_query($con,"select * from tblthreads where id='$threadid'");
while ($row=mysqli_fetch_array($query)) {
?>
<?php
$total_comments = "SELECT COUNT(*) FROM tblforumcomments WHERE postId=$threadid";
$comresult2 = mysqli_query($con,$total_comments);
$comresult = mysqli_fetch_array($comresult2)[0];
?>
                        <div>
<div class="tab" style="padding-bottom:5px;margin-top:22px;">
<div class="tab2">
<th><font size="4" style="padding:15px;"><a href="forumthread.php?pid=<?php echo htmlentities($threadid)?>" style="color:white; text-decoration:none; font-weight:bold; font-size:18px;"><?php echo $row['PostTitle'];?></a></font></th></div>
<div style="padding:15px;">
<th><font size="2" style="padding:5px;"><?php echo $row['PostingDate'];?></font></th><br><br>
<th><font size="4"><?php echo $row['PostDetails'];?></font></th><br><br>
<th><font size="3" style="padding:5px;">Posted By: <a href="profile.php?name=<?php echo $row['username'];?>"><?php echo $row['username'];?></a></font></th><br>
<th><font size="3" style="padding:5px;">Total Replies: <?php echo $comresult;?></font></th>
                            </div>
                        </div>
<?php
if ($r['active']) {
?>
</div>
<?php } else { ?>
<?php } ?>
<?php } ?>
<?php
if ($r['active'] && $username == $_SESSION['username']) {
$replyid =intval($_GET['rid']);
$queryedit=mysqli_query($con,"select * from tblforumcomments where id='$replyid'");
$editreply=mysqli_fetch_array($queryedit);
?><br>

<div class="col-md-12">
<br>
            <font size="3">Replying as: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#4CBB17"><?=$r['username'];?></font></B></font>
            <div>
              <form name="Comment" method="post">
                <input type="hidden" name="csrftoken" value="<?php echo htmlentities($_SESSION['token']); ?>" />
                <div>
                <textarea class="form-control" name="comment" rows="3" required><?php echo htmlentities($editreply['comment']);?></textarea>
                </div>
                <center><button type="submit" name="submit" class="btn-sm btn-success" style="color:black;font-size:16px;border-radius:5px;border:1px solid black;">Submit</button></center>
              </form>
<br>
            </div>
<?php } ?>
<?php 
$postid =intval($_GET['pid']);
     if (isset($_GET['pagenum'])) {
            $pageno = $_GET['pagenum'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = 5;
        $offset = ($pageno-1) * $no_of_records_per_page;
        $total_pages_sql = "SELECT COUNT(*) FROM tblforumcomments";
        $result = mysqli_query($con,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);
?>
</div></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3">
<?php
if ($r['active']) {
?>
				<div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#4CBB17"><?php echo $r['username'];?></font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="profile.php?name=<?php echo $r['username'];?>"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">My Profile</font><small class="ml-auto"></small></a>
						</li>
	                                                                                          <li><a href="logout.php"><font style="font-weight:bold; font-size:18px; text-shadow: 1px 1px 1px black;" color="#4CBB17">Logout</font><small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } else { ?>
	                                                                    <div class="widget widget-categories">
					<h5 class="widget-title"><span>Account: <font style="font-weight:bold; font-size:20px; text-shadow: 1px 1px 1px black;" color="#880808">Offline</font></span></h5>
					<ul class="list-unstyled widget-list">
						<li><a href="login.php">Login<small class="ml-auto"></small></a>
						</li>
						<li><a href="register">Create Account<small class="ml-auto"></small></a>
						</li>
					
				
					</ul>
				</div>
<?php } ?>


								<div class="widget">
			<?php 
$queryres=mysqli_query($con,"select * from tbltabs WHERE PageName='About Top'");
$rowres=mysqli_fetch_array($queryres);
?>
<?php if ($rowres['TabName'] == 'Results') { include 'tab-results.php';
} else if ($rowres['TabName'] == 'News') { include 'tab-news.php'; 
} else if ($rowres['TabName'] == 'Fixtures') { include 'tab-fixtures.php';  
} else if ($rowres['TabName'] == 'Members') { include 'tab-members.php';
}?> 		

				 </div>

	<div class="widget">
			<?php 
$queryres=mysqli_query($con,"select * from tbltabs WHERE PageName='About Bottom'");
$rowres=mysqli_fetch_array($queryres);
?>
<?php if ($rowres['TabName'] == 'Results') { include 'tab-results.php';
} else if ($rowres['TabName'] == 'News') { include 'tab-news.php'; 
} else if ($rowres['TabName'] == 'Fixtures') { include 'tab-fixtures.php';  
} else if ($rowres['TabName'] == 'Members') { include 'tab-members.php';
}?> 		
				 </div>


				 <!-- Social -->
				 <div class="widget">
				 <h4 class="widget-title"><span>Social Links</span></h4>
				 <ul class="list-unstyled list-inline mb-0 social-icons">
<?php
$query=mysqli_query($con,"select * from tblsocial WHERE Is_Active = '1'");
while($row=mysqli_fetch_array($query))
{
?>
<font size="4"><li class="list-inline-item me-3"><a class="<?php echo $row['SocialMedia'];?>" href="<?php echo $row['URL'];?>" target="_blank"  style="margin-top:5px;"><i class="fab fa-<?php echo $row['SocialMedia'];?> fa-lg"></i></a></font></li>
<?php
}
?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

<footer class="bg-tertiary">
	<div class="container">
		<div class="row align-items-center mt-5 text-center text-md-start">
			
			<div class="col-lg-12 col-md-6 mt-4 mt-lg-0">
				<ul class="list-unstyled list-inline mb-0 text-lg-center">
					<li class="list-inline-item me-4">
<center><font color="black">Copyright © 2024 All Rights Reserved | DesktopCode | </font><a href="https://www.desktopcode.com" target="_blank">www.DesktopCode.com</a></center>
					</li>

				</ul>
			</div>
		</div>
	</div>
</footer>


<!-- # JS Plugins -->
<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<script src="plugins/slick/slick.min.js"></script>
<script src="plugins/scrollmenu/scrollmenu.min.js"></script>

<!-- Main Script -->
<script src="js/script.js"></script>

</body>
</html>